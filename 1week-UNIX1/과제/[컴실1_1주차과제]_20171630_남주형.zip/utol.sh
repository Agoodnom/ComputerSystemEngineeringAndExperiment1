#!/bin/bash

echo 'working directory'
read dirname

if [ -n "$dirname" ]
then
	if [ -d "$dirname" ]
	then
		if [ -x "$dirname" ]
		then
			cd "$dirname"
		else
			echo "Error message: Impossible to change directory"
			exit 0
		fi
	else
		echo "Error message: No Directory"
		exit 0
	fi
else
	echo "Error message: you didn't tell me"
	exit 0
fi

for filename in *
do
	newfilename=$(echo $filename | tr "[a-zA-Z]" "[A-Za-z]")
	mv $filename $newfilename
done
